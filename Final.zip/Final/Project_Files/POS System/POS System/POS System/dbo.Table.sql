﻿CREATE TABLE TbProductType
(
	[ProductType] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Description] NCHAR(10) NULL
)
